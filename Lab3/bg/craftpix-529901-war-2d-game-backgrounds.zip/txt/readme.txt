Font: Bernard MT Condensed
Download: https://www.dafontfree.net/freefonts-bernard-mt-condensed-f64479.htm
Font: Agency FB Bold
Download: https://fontzone.net/font-details/agencyfb-bold